from typing import Annotated

from fastapi import APIRouter, HTTPException, Query

from app.core.config import settings
from app.schemas.market import (
    ALLOWED_KLINE_INTERVALS,
    KlineResponse,
    MarketStatus,
    TickerPrice,
)
from app.services.binance_market import BinanceMarketService

router = APIRouter(prefix="/market", tags=["Market Data"])


def normalize_symbol(symbol: str) -> str:
    normalized = symbol.strip().upper()
    if not normalized or not normalized.isalnum() or len(normalized) > 20:
        raise HTTPException(
            status_code=422,
            detail="Symbol must contain only letters and numbers",
        )
    return normalized


@router.get("/status", response_model=MarketStatus)
async def market_status() -> MarketStatus:
    service = BinanceMarketService()
    connected = await service.ping()
    return MarketStatus(
        connected=connected,
        market_data_url=settings.binance_market_base_url,
    )


@router.get("/ticker", response_model=TickerPrice)
async def ticker_price(
    symbol: Annotated[str, Query(description="Spot symbol, for example BTCUSDT")] = "BTCUSDT",
) -> TickerPrice:
    normalized_symbol = normalize_symbol(symbol)
    result = await BinanceMarketService().ticker_price(normalized_symbol)
    return TickerPrice(**result)


@router.get("/klines", response_model=KlineResponse)
async def klines(
    symbol: Annotated[str, Query(description="Spot symbol, for example BTCUSDT")] = "BTCUSDT",
    interval: Annotated[str, Query(description="Candle interval, for example 1m, 15m, 1h, 1d")] = "1h",
    limit: Annotated[int, Query(ge=1, le=1000)] = 100,
) -> KlineResponse:
    normalized_symbol = normalize_symbol(symbol)
    if interval not in ALLOWED_KLINE_INTERVALS:
        allowed = ", ".join(sorted(ALLOWED_KLINE_INTERVALS))
        raise HTTPException(status_code=422, detail=f"Unsupported interval. Allowed: {allowed}")

    candles = await BinanceMarketService().klines(normalized_symbol, interval, limit)
    return KlineResponse(
        symbol=normalized_symbol,
        interval=interval,
        limit=len(candles),
        candles=candles,
    )
