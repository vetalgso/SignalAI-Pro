from __future__ import annotations

from math import exp
from statistics import mean, pstdev
from typing import Any

from app.indicators.service import calculate_indicator_snapshot
from app.services.binance_market import BinanceMarketService


class ForecastService:
    """Transparent multi-horizon heuristic forecast. It is a baseline, not an ML model."""

    async def forecast(self, symbol: str, horizons: list[int]) -> dict[str, Any]:
        market = BinanceMarketService()
        candles = await market.klines(symbol, "1m", 500)
        closes = [float(c["close"]) for c in candles]
        volumes = [float(c["volume"]) for c in candles]
        if len(closes) < 220:
            raise ValueError("Not enough candles for forecast")

        indicators = calculate_indicator_snapshot(candles)
        current = closes[-1]
        returns = [(closes[i] / closes[i - 1] - 1.0) for i in range(1, len(closes))]
        minute_vol = pstdev(returns[-120:]) if len(returns) >= 2 else 0.0
        volume_ratio = volumes[-1] / max(mean(volumes[-20:]), 1e-12)

        payload = []
        for horizon in horizons:
            momentum_window = max(3, min(horizon, 60))
            momentum = closes[-1] / closes[-1 - momentum_window] - 1.0
            short_momentum = closes[-1] / closes[-6] - 1.0
            trend = self._trend_score(indicators)
            momentum_score = max(-1.0, min(1.0, momentum / max(minute_vol * (horizon ** 0.5), 1e-6)))
            volume_confirmation = max(-0.25, min(0.25, (volume_ratio - 1.0) * 0.25))
            raw = 0.42 * trend + 0.40 * momentum_score + 0.18 * max(-1, min(1, short_momentum / max(minute_vol * 3, 1e-6)))
            raw += volume_confirmation * (1 if raw >= 0 else -1)
            raw = max(-3.0, min(3.0, raw))

            up = 1 / (1 + exp(-1.6 * raw))
            down = 1 - up
            noise = min(0.58, max(0.08, 0.34 - abs(raw) * 0.12 + minute_vol * 80))
            up *= 1 - noise
            down *= 1 - noise
            sideways = noise
            total = up + down + sideways
            up, down, sideways = up / total, down / total, sideways / total

            best = max((up, "UP"), (down, "DOWN"), (sideways, "SIDEWAYS"))
            direction = best[1] if best[0] >= 0.48 else "UNCERTAIN"
            expected_return = raw * minute_vol * (horizon ** 0.5) * 0.72
            expected_price = current * (1 + expected_return)
            range_half = current * minute_vol * (horizon ** 0.5) * 1.65

            payload.append({
                "horizon_minutes": horizon,
                "direction": direction,
                "confidence": round(best[0] * 100),
                "probabilities": {"up": round(up, 4), "down": round(down, 4), "sideways": round(sideways, 4)},
                "expected_change_percent": round(expected_return * 100, 4),
                "predicted_price": round(expected_price, 8),
                "price_range": {"low": round(expected_price - range_half, 8), "high": round(expected_price + range_half, 8)},
                "risk_level": "high" if minute_vol > 0.0025 else "elevated" if minute_vol > 0.0012 else "normal",
                "components": {"trend": round(trend, 3), "momentum": round(momentum_score, 3), "volume_ratio": round(volume_ratio, 3)},
            })

        return {"symbol": symbol, "current_price": current, "model_version": "transparent_forecast_v1", "disclaimer": "Probabilistic heuristic forecast; not financial advice.", "forecasts": payload}

    @staticmethod
    def _trend_score(indicators: Any) -> float:
        data = indicators
        ma = data.get("moving_averages", {})
        price = float(data.get("price", 0) or 0)
        ema20 = float(ma.get("ema20") or price)
        ema50 = float(ma.get("ema50") or price)
        ema200 = float(ma.get("ema200") or price)
        score = 0.0
        score += 0.45 if ema20 > ema50 else -0.45
        score += 0.35 if ema50 > ema200 else -0.35
        score += 0.20 if price > ema200 else -0.20
        return score
