from typing import Annotated
from fastapi import APIRouter, HTTPException, Query
from app.api.market import normalize_symbol
from app.forecasting import ForecastService

router = APIRouter(prefix="/forecasts", tags=["Future Signals"])

@router.get("/current")
async def current_forecast(
    symbol: Annotated[str, Query()] = "BTCUSDT",
    horizons: Annotated[str, Query(description="Comma-separated minutes")] = "10,30,60",
):
    normalized = normalize_symbol(symbol)
    try:
        values = sorted(set(int(x.strip()) for x in horizons.split(",") if x.strip()))
    except ValueError as exc:
        raise HTTPException(422, "Horizons must be integers") from exc
    if not values or any(x < 5 or x > 1440 for x in values) or len(values) > 8:
        raise HTTPException(422, "Use 1-8 horizons between 5 and 1440 minutes")
    try:
        return await ForecastService().forecast(normalized, values)
    except ValueError as exc:
        raise HTTPException(422, str(exc)) from exc
